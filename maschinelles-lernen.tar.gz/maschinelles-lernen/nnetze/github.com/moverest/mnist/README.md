Package mnist provides a simple interface to parse and use the MNIST database. It does not come with the database, you have to download the files and put them in the same directory to be easly loaded with the Load function.

For more information and to download the database, see http://yann.lecun.com/exdb/mnist/.
