package nnetze

// Vor.: -
// Erg.: Ein neuronales Netz, dass die sigmoid-Funktion als "activation"
//       benutzt, ist geliefert. Dieses Modell kann nach dem
//       Trainieren eine Klassifikation von l Klassen vornehmen, was der
//       Anzahl der Neuronen im "output layer" entspricht. k ist die
//       Anzahl der Neuronen im "hidden layer".
// New(k, l int)

type NNetz interface {

	// Vor.: -
	// Eff.: Trainingsdaten werden aus dem Mnist-Set eingelesen. Die
	//       vier Mnist-Dateien t10k-images-idx3-ubyte.gz,
	//       t10k-labels-idx1-ubyte.gz, train-images-idx3-ubyte.gz und
	//       train-labels-idx1-ubyte.gz müssen dabei im Ordner f liegen.
	TrainingsdatenEinlesenAusMnist(d string)

	// Vor.: -
	// Eff.: Trainingsdaten werden aus PNG-Graustufenbildern eingelesen.
	//       Die Bilder müssen die gleichen Dimensionen haben.
	//       In der Datei d wird festgelegt, welche Bilder eingelesen
	//       werden. Zusätzlich ist dort notiert, zu welcher Klasse die
	//       Bilder jeweils gehören. Die Datei muss folgendermaßen
	//       formatiert sein:
	//
	//       katze.png 0
	//       puma.png 1
	//       luchs.png 2
	//       ...
	//
	//	     Die letzte Zeile des Dokumentes muss mit einem
	//       Zeilenumbruch enden.
	TrainingsdatenEinlesenAusPngGraustufen(strain string)

	////////////////////////////////////////////////////////////////////

	// Vor.: Trainingsdaten wurden eingelesen.
	// Eff.: Anhand der eingelesenen Trainingsdaten wird das neuronale
	//       Netz mit einen stochastischen Gradientenverfahren
	//       trainiert. a ist dabei der Lernparameter. Dieser gibt an,
	//       wie schnell das Modell anhand der Daten lernt. Wählt man a
	//       zu groß, kann es sein, dass das Gradientenverfahren nicht
	//       funktioniert. n ist die Anzahl der Iterationen, gibt also
	//       an, wie viele Male die Trainingsdaten für das
	//       Gradientenverfahren benutzt werden.
	GradientenverfahrenStochastisch(a float64, n int)

	////////////////////////////////////////////////////////////////////

	// Vor.: Das neuronale Netz wurde trainiert.
	// Eff.: Trainingsdaten werden aus dem Mnist-Set eingelesen. Die
	//       vier Mnist-Dateien t10k-images-idx3-ubyte.gz,
	//       t10k-labels-idx1-ubyte.gz, train-images-idx3-ubyte.gz und
	//       train-labels-idx1-ubyte.gz müssen dabei im Ordner f liegen.
	// Erg.: Der Anteil der korrekt klassifizierten Bilder ist geliefert.
	TestdatenAuswertenAusMnist(d string)

	// Vor.: Das neuronale Netz wurde trainiert.
	// Eff.: Trainingsdaten werden aus PNG-Graustufenbildern eingelesen.
	//       In der Datei d wird festgelegt, welche Bilder eingelesen
	//       werden. Zusätzlich ist dort notiert, zu welcher Klasse die
	//       Bilder jeweils gehören. Die Datei muss folgendermaßen
	//       formatiert sein:
	//
	//       katze.png 0
	//       puma.png 1
	//       luchs.png 2
	//       ...
	//
	//	     Die letzte Zeile des Dokumentes muss mit einem
	//       Zeilenumbruch enden.
	// Erg.: Der Anteil der korrekt klassifizierten Bilder ist geliefert.
	TestdatenAuswertenAusPngGraustufen(stest string)

	////////////////////////////////////////////////////////////////////

	// Vor.: Das neuronale Netz wurde trainiert.
	// Erg.: Die "Weights" des "hidden neuron" i ist geliefert.
	W(i int) []float64

	// Vor.: Das neuronale Netz wurde trainiert.
	// Erg.: Der "Bias" des "hidden neuron" i ist geliefert.
	B(i int) float64

	// Vor.: Das neuronale Netz wurde trainiert.
	// Erg.: Die "Weights" des k-ten "hidden neuron" werden in einen gfx-Fenster
	//       dargestellt. Die Farbe Rot steht für positive "Weights",
	//       die Farbe Blau für negative "Weights".
	Darstellen(k int)
	
	// Vor.: Das neuronale Netz wurde trainiert.
	// Erg.: Ein Grafikfenster mit weißem Hintergrund wird erstellt,
	//       damit der Benutzer eine Zahl zeichnen kann.
	//       Nach Drücken der rechten Maustaste und einer beliebigen
	//       Tastatur-Taste wird eine Wahrscheinlichkeitsverteilung
	//       für die zehn Ziffern ("Output Neuronen") ausgegeben.
	//       Zusätzlich wird die Ziffer mit der höchsten Wahrscheinlichkeit
	//       als Prognose ausgegeben.
	Zeichnen()
	
	// Vor.: Das neuronale Netz wurde trainiert.
	// Erg.: Die trainierten "Weights" und "Baises" werden in dem
	//       angegebenen Speicherort abgelegt.
	// Speichern(speicherort string)
	
	// Vor.: Die Methode Speichern muss vorher ausgeführt worden sein;
	//       die daraus resultierende Datei ist unter dem angegebenen
	//       Speicherort abgelegt.
	// Eff.: Die "Weights" und "Baises" aus der angegebenen Datei sind
	//       in das Modell geladen.
	// Laden(speicherort string)
}
