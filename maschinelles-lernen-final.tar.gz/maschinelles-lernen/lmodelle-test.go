package main

import (
	"fmt"
	"gfx"
	"./lmodelle";
)

func main() {
	
	anzKlassen := 10 		// Anzahl der zu klassifizierenden Ziffern (hier: 0-9)
	lernparameter := 0.01 	// Schrittweite, mit der das Modell anhand der Daten lernt
	anzIterationen := 10	// wie oft das Trainingsset beim Lernen durchlaufen wird
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println(anzKlassen, "Klassen")
	fmt.Println("-----------------------------------------------------")
	fmt.Println("Lernparameter:", lernparameter, "| Anzahl Iterationen:", anzIterationen)

	l := lmodelle.New(anzKlassen)
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("... Trainingsdaten werden eingelesen ...")
	
	l.TrainingsdatenEinlesenAusMnist("./mnist")
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("... Lineares Modell wird trainiert ...")
	
	l.GradientenverfahrenStochastisch(lernparameter, anzIterationen)
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("... Testdaten werden eingelesen ...")
	fmt.Println("-----------------------------------------------------")
	
	l.TestdatenAuswertenAusMnist("./mnist")
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("Visualisierung der Klassen:")
	fmt.Println("")
	
	for i := 0; i < anzKlassen; i++ { // "Weights" der Klasse k werden dargestellt
		l.Darstellen(i)               // hier: 0-9
	}
	
	gfx.FensterAus()
	
	fmt.Println("-----------------------------------------------------")
	
	fmt.Println("Jetzt können Sie selbst eine Zahl von 0 bis 9 zeichnen:")
	for { // Endlosschleife zum selbstständigen Zeichnen der Ziffern
		l.Zeichnen()
	}

}
