package main

import (
	"fmt"
	"gfx"
	"./nnetze"
)

func main() {
	
	anzHiddenNeuronen := 30 // Anzahl der Neuronen im "Hidden Layer"
	anzOutputNeuronen := 10	// Anzahl der zu klassifizierenden Ziffern (hier: 0-9)
	lernparameter := 0.01   // Schrittweite, mit der das Modell anhand der Daten lernt
	anzIterationen := 3     // wie oft das Trainingsset beim Lernen durchlaufen wird
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println(anzHiddenNeuronen, "Hidden Neuronen |", anzOutputNeuronen, "Output Neuronen")
	fmt.Println("-----------------------------------------------------")
	fmt.Println("Lernparameter:", lernparameter, "| Anzahl Iterationen:", anzIterationen)
	
	n := nnetze.New(anzHiddenNeuronen, anzOutputNeuronen)
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("... Trainingsdaten werden eingelesen ...")
	
	n.TrainingsdatenEinlesenAusMnist("./mnist")
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("... Neuronales Netz wird trainiert ...")
	
	n.GradientenverfahrenStochastisch(lernparameter, anzIterationen)
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("... Testdaten werden eingelesen ...")
	fmt.Println("-----------------------------------------------------")
	
	n.TestdatenAuswertenAusMnist("./mnist")
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("Visualisierung der Hidden Neuronen:")
	fmt.Println("")
	
	for i := 0; i < anzHiddenNeuronen; i++ { // "Weights" der "Hidden Neuronen" werden dargestellt
		n.Darstellen(i)
	}
	
	gfx.FensterAus()
	
	fmt.Println("-----------------------------------------------------")
	fmt.Println("Jetzt können Sie selbst eine Zahl von 0 bis 9 zeichnen:")
	
	for { // Endlosschleife zum selbstständigen Zeichnen der Ziffern
		n.Zeichnen()
	}

}
